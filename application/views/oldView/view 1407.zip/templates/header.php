﻿<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <link rel="icon" type="image/png" sizes="16x16" href="<?=base_url()?>public/assets/images/favicon.png">
    <title><?=$page_title?></title>
	
   <link href="<?=base_url()?>public/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="<?=base_url()?>public/assets/node_modules/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?=base_url()?>public/assets/node_modules/switchery/dist/switchery.min.css" rel="stylesheet" />
	<link href="<?=base_url()?>public/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/datatables/media/css/dataTables.bootstrap4.css" rel="stylesheet">
	<link href="<?=base_url()?>public/assets/node_modules/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
	<link href="<?=base_url()?>public/assets/node_modules/dropzone-master/dist/dropzone.css" rel="stylesheet" type="text/css" />
    <link href="<?=base_url()?>public/dist/css/style.min.css" rel="stylesheet">
    <link href="<?=base_url()?>public/dist/css/pages/file-upload.css" rel="stylesheet">
	<link href="<?=base_url()?>public/assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/clockpicker/dist/jquery-clockpicker.min.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/jquery-asColorPicker-master/dist/css/asColorPicker.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="<?=base_url()?>public/assets/node_modules/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<link href="<?=base_url()?>public/dist/css/pages/widget-page.css" rel="stylesheet">
	    <link href="<?=base_url()?>public/assets/node_modules/tablesaw-master/dist/tablesaw.css" rel="stylesheet">
	    <link href="<?=base_url()?>public/assets/node_modules/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/node_modules/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
	 <link type="text/css" rel="stylesheet" href="<?=base_url()?>public/assets/node_modules/jsgrid/jsgrid.min.css" />
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>public/assets/node_modules/jsgrid/jsgrid-theme.min.css" />
<link href="https://fonts.googleapis.com/css?family=El+Messiri&amp;subset=arabic,cyrillic" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

 <link href="<?=base_url()?>public/dist/css/all.css" rel="stylesheet">

	
	   <script src="<?=base_url()?>public/assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
          

	       <!--<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>--->
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries --->
    <!-- WARNING: Respond.js doesn't work if you view the page via file: --->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif] -->

<script type="text/javascript">

  
	function chkBox(selector)
	{
		if($(selector).is(":checked"))
		{
			return 1;
		}
		else{ return 0;}
	}
	function draw(url , selector )
	{
	    $('#example').dataTable().fnDestroy();
		 $.ajax({
				url : url , 
				 beforeSend: function ( xhr )
				 {
					 xhr.overrideMimeType("text/plain; charset=utf-8");
				 } ,
				type: 'POST',  
				data:{random:Math.random()} ,  
				success:function(data) 
				 {
					 $(selector).html(data);
					 setTimeout(function(){
					       $('#example').DataTable();
                        					     
					 },700);
				 }
			 });
	  }
	  function _PREFIX()
		{
		  return m_PREFIX = document.getElementById("_PRIFIX").value;
	    }
		function get_chkbox_val(selector)
		{
			if($(selector).is(":checked"))
			{
				return 1;
			}
			else{ return 0;}
		}
      	function fetch_all(url , selector)
		{  
			$.ajax({
			   url : url, 
			   type:'POST', 
			   data:{random:Math.random()} , 
			   success: function(data)
			   { $(selector).html(data);$('#example').DataTable();}
			 });
		}
		function fetch_per_params(url , selector ,  right_val , prfx_type , actv=-1)
		{
 			$.ajax({
			   url : url, 
			   type:'POST', 
			   data:{random:Math.random() , 
			      post_val    : right_val ,
				  prefix_type : prfx_type , 
				  active      : actv
			   } , 
			   success: function(data)
			   { $(selector).html(data);$('#example').DataTable();}
			 });
		}
			function draw_such_params(url , selector , params )
	{
		//var arr =  $("param_selector,param_selector").serialize()
		 $.ajax({
				url : url , 
				 beforeSend: function ( xhr )
				 {
					 xhr.overrideMimeType("text/plain; charset=utf-8");
				 } ,
				type: 'POST',  
				data:   params   ,  
				success:function(data) 
				 {
					 $(selector).html(data);
					 setTimeout(function(){$('#example').DataTable();},700);
				 }
			 });
    }
		
</script>
</head>

<body class="skin-blue fixed-layout">
 <?php  
		      $menus = $this->main_model->get_menus(); 	
			$this->load->view('alert');	
			 
		 ?>
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label"><?=$page_title?></p>
        </div>
    </div>

    <div id="main-wrapper">

        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">

                <div class="navbar-header">
                    <a class="navbar-brand" href="<?=base_url()?>/Home">
                       <b>
                       
                       
                            <img src="<?=base_url()?>public/assets/images/logo-icon.png" alt="homepage" class="dark-logo" />
                            <!-- Light Logo icon --->
                            <img src="<?=base_url()?>public/assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <!--End Logo icon --->
                        <!-- Logo text ---><span>
                         <!-- dark Logo text --->
                         <img src="<?=base_url()?>public/assets/images/logo-text.png" alt="homepage" class="dark-logo" />
                         <!-- Light Logo text --->    
                         <img src="<?=base_url()?>public/assets/images/logo-light-text.png" class="light-logo" alt="homepage" /></span> </a>
                </div>
                <!-- ============================================================== --->
                <!-- End Logo --->
                <!-- ============================================================== --->
                <div class="navbar-collapse">
                    <!-- ============================================================== --->
                    <!-- toggle and nav items --->
                    <!-- ============================================================== --->
                    <ul class="navbar-nav mr-auto">
                        <!-- This is  --->
                        <li class="nav-item"> <a class="nav-link nav-toggler d-block d-md-none waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item"> <a class="nav-link sidebartoggler d-none d-lg-block d-md-block waves-effect waves-dark" href="javascript:void(0)"><i class="icon-menu"></i></a> </li>
                        <!-- ============================================================== --->
                        <!-- Search --->
                        <!-- ============================================================== --->
                        <li class="nav-item">
                            <form class="app-search d-none d-md-block d-lg-block">
                                <input type="text" class="form-control" placeholder="<?php echo $this->lang->line("Search_enter");?>">
                            </form>
                        </li>
                    </ul>
                    <!-- ============================================================== --->
                    <!-- User profile and search --->
                    <!-- ============================================================== --->
			

                    <ul class="navbar-nav my-lg-0">
							 <li class="nav-item dropdown u-pro">
                            <a class="nav-link dropdown-toggle waves-effect "   data-toggle='modal' data-target='#send_mess'  aria-haspopup="true" aria-expanded="false">
							<img src="<?=base_url()?>public/assets/images/icon/send.png"   /></a>
                             </li>
					<li class="nav-item dropdown">
					
                            <a class="nav-link dropdown-toggle " href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
							<img src="<?=base_url()?>public/assets/images/icon/in.png" alt="user" >
                                <div class="notify">  </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated bounceInDown">
                                <ul>
                                    <li>
                                        <div class="drop-title"><?=$this->lang->line('Notifications');?></div>
                                    </li>
                                    <li>
                                        <div class="message-center ps ps--theme_default" data-ps-id="38753e3d-e9a4-21b4-e619-6b8228e258e2">
										
										<?php
							
		$seld =  $this->db->query("select * from msgs where usrto = ".$this->session->userdata('User_code')." order by id DESC LIMIT 5")->result();
										foreach($seld  as $d315 )
			                                 { 
					$this->db->select('u_fname');
                     $this->db->from('users');
                     $this->db->where('u_code',$d315->userid);
                     $q = $this->db->get()->row()->u_fname;                
                     $datt =  date('Y-m-d',strtotime($d315->date))                         
						?>
									
                                        <a href="javascript:void(0)">
                                                <div class="btn btn-danger btn-circle"><i class="fa fa-link"></i></div>
                                                <div class="mail-contnet">
                                              <h5><?php echo $q?></h5> <span class="mail-desc"> <span class="text-success"><?php echo $d315->title?></span>: <?php echo $d315->full?></span> <span class="time"><?php echo $datt?></span> </div>
                                            
                                     
											<?php }
										?>
                                            
                                         
                                        <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: -6px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center link" href="javascript:void(0);"> <strong><?=$this->lang->line('Check_ll_notifications');?></strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <!-- ============================================================== --->
                        <!-- User Profile --->
                        <!-- ============================================================== --->
                        <li class="nav-item dropdown u-pro">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<img src="<?=base_url()?>public/assets/images/users/<?php if ($this->session->userdata('User_sex') =="Male")echo "2.png"; else echo "1.png";?>" alt="user" class=""> <span class="hidden-md-down"><?=$this->session->userdata('User_fullname')?> &nbsp;<i class="fa fa-angle-down"></i></span> </a>
                            <div class="dropdown-menu dropdown-menu-right animated flipInY">
                                <!-- text--->
                                <a href="Myaccount" class="dropdown-item"><i class="ti-user"></i> <?= $this->lang->line("profile");?></a>
                                <div class="dropdown-divider"></div>
                                <!-- text--->
                                <a href="<?=base_url()?>login/logout" class="dropdown-item"><i class="fa fa-power-off"></i> <?= $this->lang->line("LogOut");?></a>
                                <!-- text--->
                            </div>
                        </li>
                        <!-- ============================================================== --->
                        <!-- End User Profile --->
                        <!-- ============================================================== --->
                      
                    </ul>
                </div>
            </nav>
        </header>

		
        <aside class="left-sidebar">
            <!-- Sidebar scroll--->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation--->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src="<?=base_url()?>public/assets/images/users/<?php if ($this->session->userdata('User_sex') =="Male")echo "2.png"; else echo "1.png";?>" alt="user-img" class="img-circle"><span class="hide-menu">  <?=$this->session->userdata('User_fullname')?>  </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="Myaccount"><i class="ti-user"></i> <?= $this->lang->line("profile");?></a></li>
                                <li><a href="Myaccount"><i class="ti-user"></i> <?= $this->lang->line("Settings");?></a></li>
                                <li><a href="<?=base_url()?>login/logout"><i class="fa fa-power-off"></i> <?= $this->lang->line("LogOut");?></a></li>
                            </ul>
                        </li>
				
            
                        <li class="nav-small-cap">--- <?=$this->lang->line("Main");?>---</li>
						   	    <div class="fixed-sidebar-left">
			<ul class="nav navbar-nav side-nav nicescroll-bar">
				
             <?php 
 			   if($this->main_model->get_settings('is_with_permission') == 1)
			   {
 			      if($this->session->userdata('User_type') == 1 && $this->session->userdata('User_code') == 1)
				   {
				    
					  foreach($menus as $me){
					 	 $scren = $this->main_model->get_screens($me->m_code);
						  if(count($scren) > 0 )
						  {
				 ?>   
				<li>
					<a href="javascript:void(0);" data-toggle="collapse" data-target="#menu<?=$me->m_code?>">
                        <div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i>
                        <span class="right-nav-text"><?=$me->m_name?></span></div>
                        <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
                        <div class="clearfix"></div>
                     </a>
					<ul id="menu<?=$me->m_code?>" class="collapse collapse-level-1">
                      <?php  foreach($scren as $scr){?>
						<li>
							<a class="active-page" href="<?=base_url().$scr->s_url?>" title="<?=$scr->s_symbol?>"><?=$scr->s_name?></a>
						</li>
						<?php  }?> 
					</ul>
				</li>
                <?php 
						  } 
					  }
				 	} 
				 else
					{
 						foreach($menus as $me)
						{
					 	   $scren = $this->main_model->get_perm_scr_menu($me->m_code);
							if(count($scren) > 0 )
							{
 						 ?>
						<li>
                            <a href="javascript:void(0);" data-toggle="collapse" data-target="#menu<?=$me->m_code?>">
                                <div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i>
                                <span class="right-nav-text"><?=$me->m_name?></span></div>
                                <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
                                <div class="clearfix"></div>
                             </a>
                            <ul id="menu<?=$me->m_code?>" class="collapse collapse-level-1">
                              <?php  foreach($scren as $scr){?>
                                <li>
                                    <a class="active-page" href="<?=base_url().$scr->s_url?>" title="<?=$scr->s_symbol?>"><?=$scr->s_name?></a>
                                </li>
                                <?php  }?> 
                            </ul>
                        </li>
					<?php 
							}
					   }
					
					}
			   }
				   else
				   {
					   echo 'in else ';
					   // Manual Screens 
				    	
				     }
				  ?>
				<li><hr class="light-grey-hr mb-10"/></li>	
 			</ul>
	    </div>         
                       
                        <li class="nav-small-cap">---<?=$this->lang->line('SUPPORT');?>---</li>
						    <li> <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="far fa-circle text-success"></i><span class="hide-menu"><?= $this->lang->line("help");?></span></a></li>
                        <li> <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="far fa-circle text-info"></i><span class="hide-menu"><?= $this->lang->line("Reports");?></span></a></li>
                        <li> <a class="waves-effect waves-dark" href="<?=base_url()?>login/logout" aria-expanded="false"><i class="far fa-circle text-danger"></i><span class="hide-menu"><?= $this->lang->line("LogOut");?></span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation --->
            </div>
            <!-- End Sidebar scroll--->
        </aside>
        <!-- ============================================================== --->
        <!-- End Left Sidebar - style you can find in sidebar.scss  --->
        <!-- ============================================================== --->
        <!-- ============================================================== --->
        <!-- Page wrapper  --->
        <!-- ============================================================== --->
        <div class="page-wrapper">
            <!-- ============================================================== --->
            <!-- Container fluid  --->
            <!-- ============================================================== --->
            <div class="container-fluid">
              