</div>
</div>
</div> 

<div class="modal fade" id="send_mess" tabindex="-1" role="dialog" aria-labelledby="send_mess">
	<div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
	   <h4 class="modal-title" id="send_mess"><?=$this->lang->line("send_new_mees")?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       
      </div>
      <div class="modal-body">
      <div id="alert"></div>
       <form method="post" enctype="multipart/form-data" id="mess_form">
		 <div class="row">
			<div class="col-md-12">
							 <div class="form-group">
							 <label class="control-label mb-4">
								  <?=$this->lang->line('send_to');?>
								  </label>
									  <select class="form-control" id="usrto" name="usrto">
										<option value=""><?=$this->lang->line('choose');?></option>
										<?php 
										  draw_lists("users" , "u_code" , "u_fname");
										?>
									</select>
								</div>
							 </div>

			<div class="col-md-12">
					<div class="form-group">
					  <label class="control-label mb-10"><?=$this->lang->line('title');?></label>
					  <div class='input-group date'>
							<input type='text'  class="form-control" id="title" name="title" />
						
						</div>
					  </div>
				 </div>      
		
			<div class="col-md-12">
						<div class="form-group">
					  <label class="control-label mb-10">
					  <?=$this->lang->line('full_mess');?>	</label>
						  <textarea class="form-control" id="full" name="full"></textarea>
						 </div>
					</div>  

		
			  	<div class="col-md-12">
				<button type="button" class="btn btn-default" data-dismiss="modal"><?=$this->lang->line('Close');?></button>
				<button type="submit" id="send_mess" class="btn btn-primary"><?=$this->lang->line('send');?></button>
			  </div>
		 </form>
      </div>
     
    </div>
  </div>
			</div>
			</div>		
<!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer">
            © 2018 Mismail-As'adMansour
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    
 
    <!-- slimscrollbar scrollbar JavaScript -->
    	 
    <!-- Bootstrap tether Core JavaScript -->

    <script src="<?=base_url()?>public/assets/node_modules/popper/popper.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="<?=base_url()?>public/dist/js/perfect-scrollbar.jquery.min.js"></script>
	<script src="<?=base_url()?>public/dist/js/waves.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="<?=base_url()?>public/dist/js/sidebarmenu.js"></script>

    <script src="<?=base_url()?>public/dist/js/pages/jasny-bootstrap.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/toast-master/js/jquery.toast.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/sweetalert/sweetalert2.all.js"></script>
		<script src="<?=base_url()?>public/dist/js/pages/validation.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/dropzone-master/dist/dropzone.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
    <script src="<?=base_url()?>public/dist/js/pages/mask.init.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>public/assets/node_modules/moment/moment.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/clockpicker/dist/jquery-clockpicker.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/gauge/gauge.min.js"></script>
	 <script src="<?=base_url()?>public/assets/node_modules/tablesaw-master/dist/tablesaw.jquery.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/tablesaw-master/dist/tablesaw-init.js"></script>
	    <script src="<?=base_url()?>public/assets/node_modules/datatables/datatables.min.js"></script> 
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script> 
 <script defer src="<?=base_url()?>public/dist/js/all.js"></script>

  
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
    <script src="<?=base_url()?>public/assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
    <script src="<?=base_url()?>public/assets/node_modules/dff/dff.js" type="text/javascript"></script>
      <script type="text/javascript" src="<?=base_url()?>public/assets/node_modules/multiselect/js/jquery.multi-select.js"></script>

	    <script src="<?=base_url()?>public/dist/js/custom.min.js"></script>
    
	

    <script>
	
	  $(".select2").select2();
    ! function(window, document, $) {
        "use strict";
        $("input,select,textarea").not("[type=submit]").jqBootstrapValidation();
    }(window, document, jQuery);
      $('#min-date9').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD hh:mm A' });
    $('#min-date8').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD hh:mm A' });
    $('#min-date').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD hh:mm A',  ampm: true, minDate: new Date() });
    $('#min-date1').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD hh:mm A', ampm: true,  minDate: new Date() });
	$('#min-date3').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD', ampm: true });
	$('#min-date7').bootstrapMaterialDatePicker({ format: 'YYYY-MM-DD',weekStart: 0, time: false });
	$('#min-date8').bootstrapMaterialDatePicker({ format: 'YYYY-MM-DD',weekStart: 0, time: false });
	$('#min-date2').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD',weekStart: 0, time: false });
	$('#min-date4').bootstrapMaterialDatePicker({ format: 'YYYY/MM/DD',weekStart: 0, time: false });
      <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
    var config = {
        '.chosen-select'           : {},
        '.chosen-select-deselect'  : {allow_single_deselect:true},
        '.chosen-select-no-single' : {disable_search_threshold:10},
        '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
        '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
        $(selector).chosen(config[selector]);
    }
</script>
      <script>
      $(document).ready(function()
      {
          $("#file").change(function() {
              $("#message").empty(); // To remove the previous error message
              var file = this.files[0];
              var imagefile = file.type;
              var match= ["image/jpeg","image/png","image/jpg"];
              if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
              {
                  $('#previewing').attr('src','noimage.png');
                  $("#message").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
                  return false;
              }
              else
              {
                  var reader = new FileReader();
                  reader.onload = imageIsLoaded;
                  reader.readAsDataURL(this.files[0]);
              }
          });
          $(document).on('click','.photo_main',function(){
              if(confirm('<?php echo $this->lang->line("are_you_sure");?>'))
              {
                  var s_code = $(this).parent().parent().attr('S_code');
                  var Rcus = $(this).parent().parent().attr('rcu');
                  var ismain = 0;
                  if($(this).is(":checked"))
                      ismain = 1
                  else
                      ismain = 0;
                  var  prefix = _PREFIX();
                  $.ajax({
                      url : '<?=base_url()?>common/set_photo_main' ,
                      type: 'POST' ,
                      data: {random:Math.random() ,
                          S_code : s_code ,
                          is_main : ismain ,
                          prefix_type : prefix,
                          rcu         : Rcus
                      },
                      success: function(data)
                      {
                          fetch_per_params('<?=base_url()?>common/fetch_this_photos' , '#this_photos'  , Rcus , _PREFIX());// fetch all photos
                      }
                  });
              }
          });
          $(document).on('click','.photo_slider',function(){
              if(confirm('<?php echo $this->lang->line("are_you_sure");?>'))
              {
                  var s_code = $(this).parent().parent().attr('S_code');
                  var Rcus = $(this).parent().parent().attr('rcu');
                  var Pcode = $(this).parent().parent().attr('P_code');
                  var isslider = 0;
                  if($(this).is(":checked"))
                      isslider = 1
                  else
                      isslider = 0;
                  var  prefix = _PREFIX();
                  $.ajax({
                      url : '<?=base_url()?>common/set_photo_slider' ,
                      type: 'POST' ,
                      data: {random:Math.random() ,
                          S_code : s_code ,
                          is_slider : isslider ,
                          prefix_type : prefix,
                          rcu         : Rcus ,
                          P_code      : Pcode
                      },
                      success: function(data)
                      {
                          fetch_per_params('<?=base_url()?>common/fetch_this_photos' , '#this_photos'  , Rcus , _PREFIX());// fetch all photos
                      }
                  });
              }
          });
          $(document).on('click','.photo_active',function(){
              if(confirm('<?php echo $this->lang->line("are_you_sure");?>'))
              {
                  var s_code = $(this).parent().parent().attr('S_code');
                  var actives = 0;
                  if($(this).is(":checked"))
                      actives = 1
                  else
                      actives = 0;
                  var  prefix = _PREFIX();
                  $.ajax({
                      url : 'common/set_photo_active' ,
                      type: 'POST' ,
                      data: {random:Math.random() ,
                          S_code : s_code ,
                          active : actives
                      },
                      success: function(data)
                      {
                          fetch_per_params('common/fetch_this_photos' , '#this_photos'  , Rcus , _PREFIX());// fetch all photos
                      }
                  });
              }
          });

          $(document).on('click','.Del_photo',function(){
              var pk = $(this).attr('title');
              var rcu = $(this).attr('rcu'); // FK for item in subject photo
              if(confirm('<?php echo $this->lang->line("Confirm_del");?>'))
              {
                  $.ajax({
                      url : 'common/del_this_photo/'+pk + '/'+rcu + '/'+ _PREFIX(),
                      type: 'POST' ,
                      data: {random:Math.random()
                      },
                      success: function(data)
                      {
                          alert(data);
                          fetch_per_params('common/fetch_this_photos' , '#this_photos'  , rcu , _PREFIX());// fetch all photos
                      }
                  });
              }
              else{alert('<?php echo $this->lang->line("cancel_Confirm_del");?>');}
          }); // Photo Delete Event for all
      });
      $(function() {
          var availableTags =  [
              "public/Flags/24/ASEAN.png",
              "public/Flags/24/Afghanistan.png",
              "public/Flags/24/African Union(OAS).png",
              "public/Flags/24/Albania.png",
              "public/Flags/24/Algeria.png",
              "public/Flags/24/American Samoa.png","public/Flags/24/Andorra.png","public/Flags/24/Angola.png",
              "public/Flags/24/Anguilla.png",
              "public/Flags/24/Antarctica.png",
              "public/Flags/24/Antigua & Barbuda.png",
              "public/Flags/24/Arab League.png",
              "public/Flags/24/Argentina.png",
              "public/Flags/24/Armenia.png",
              "public/Flags/24/Aruba.png",
              "public/Flags/24/Australia.png",
              "public/Flags/24/Austria.png",
              "public/Flags/24/Azerbaijan.png",
              "public/Flags/24/Bahamas.png",
              "public/Flags/24/Bahrain.png",
              "public/Flags/24/Bangladesh.png",
              "public/Flags/24/Barbados.png",
              "public/Flags/24/Belarus.png",
              "public/Flags/24/Belgium.png",
              "public/Flags/24/Belize.png",
              "public/Flags/24/Benin.png",
              "public/Flags/24/Bermuda.png",
              "public/Flags/24/Bhutan.png",
              "public/Flags/24/Bolivia.png",
              "public/Flags/24/Bosnia & Herzegovina.png",
              "public/Flags/24/Botswana.png",
              "public/Flags/24/Brazil.png",
              "public/Flags/24/Brunei.png",
              "public/Flags/24/Bulgaria.png",
              "public/Flags/24/Burkina Faso.png",
              "public/Flags/24/Burundi.png",
              "public/Flags/24/CARICOM.png",
              "public/Flags/24/CIS.png",
              "public/Flags/24/Cambodja.png",
              "public/Flags/24/Cameroon.png",
              "public/Flags/24/Canada.png",
              "public/Flags/24/Cape Verde.png",
              "public/Flags/24/Cayman Islands.png",
              "public/Flags/24/Central African Republic.png",
              "public/Flags/24/Chad.png",
              "public/Flags/24/Chile.png",
              "public/Flags/24/China.png",
              "public/Flags/24/Colombia.png",
              "public/Flags/24/Commonwealth.png",
              "public/Flags/24/Comoros.png",
              "public/Flags/24/Congo-Brazzaville.png",
              "public/Flags/24/Congo-Kinshasa.png",
              "public/Flags/24/Cook Islands.png",
              "public/Flags/24/Costa Rica.png",
              "public/Flags/24/Cote d'Ivoire.png",
              "public/Flags/24/Croatia.png",
              "public/Flags/24/Cuba.png",
              "public/Flags/24/Cyprus.png",
              "public/Flags/24/Czech Republic.png",
              "public/Flags/24/Denmark.png",
              "public/Flags/24/Djibouti.png",
              "public/Flags/24/Dominica.png",
              "public/Flags/24/Dominican Republic.png",
              "public/Flags/24/Egypt.png",
              "public/Flags/24/El Salvador.png",
              "public/Flags/24/England.png",
              "public/Flags/24/Equador.png",
              "public/Flags/24/Equatorial Guinea.png",
              "public/Flags/24/Eritrea.png",
              "public/Flags/24/Estonia.png",
              "public/Flags/24/Ethiopia.png",
              "public/Flags/24/European Union.png",
              "public/Flags/24/Faroes.png",
              "public/Flags/24/Fiji.png",
              "public/Flags/24/Finland.png",
              "public/Flags/24/France.png",
              "public/Flags/24/Gabon.png",
              "public/Flags/24/Gambia.png",
              "public/Flags/24/Georgia.png",
              "public/Flags/24/Germany.png",
              "public/Flags/24/Ghana.png",
              "public/Flags/24/Gibraltar.png",
              "public/Flags/24/Greece.png",
              "public/Flags/24/Greenland.png",
              "public/Flags/24/Grenada.png",
              "public/Flags/24/Guadeloupe.png",
              "public/Flags/24/Guam.png",
              "public/Flags/24/Guatemala.png",
              "public/Flags/24/Guernsey.png",
              "public/Flags/24/Guinea-Bissau.png",
              "public/Flags/24/Guinea.png",
              "public/Flags/24/Guyana.png",
              "public/Flags/24/Haiti.png",
              "public/Flags/24/Honduras.png",
              "public/Flags/24/Hong Kong.png",
              "public/Flags/24/Hungary.png",
              "public/Flags/24/Iceland.png",
              "public/Flags/24/India.png",
              "public/Flags/24/Indonesia.png",
              "public/Flags/24/Iran.png",
              "public/Flags/24/Iraq.png",
              "public/Flags/24/Ireland.png",
              "public/Flags/24/Islamic Conference.png",
              "public/Flags/24/Isle of Man.png",
              "public/Flags/24/Israel.png",
              "public/Flags/24/Italy.png",
              "public/Flags/24/Jamaica.png",
              "public/Flags/24/Jersey.png",
              "public/Flags/24/Jordan.png",
              "public/Flags/24/Kazakhstan.png",
              "public/Flags/24/Kenya.png",
              "public/Flags/24/Kiribati.png",
              "public/Flags/24/Kosovo.png",
              "public/Flags/24/Kuwait.png",
              "public/Flags/24/Kyrgyzstan.png",
              "public/Flags/24/Laos.png",
              "public/Flags/24/Latvia.png",
              "public/Flags/24/Lebanon.png",
              "public/Flags/24/Lesotho.png",
              "public/Flags/24/Liberia.png",
              "public/Flags/24/Libya.png",
              "public/Flags/24/Liechtenstein.png",
              "public/Flags/24/Lithuania.png",
              "public/Flags/24/Luxembourg.png",
              "public/Flags/24/Macao.png",
              "public/Flags/24/Macedonia.png",
              "public/Flags/24/Madagascar.png",
              "public/Flags/24/Malawi.png",
              "public/Flags/24/Malaysia.png",
              "public/Flags/24/Maldives.png",
              "public/Flags/24/Mali.png",
              "public/Flags/24/Malta.png",
              "public/Flags/24/MarshallIslands.png",
              "public/Flags/24/Martinique.png",
              "public/Flags/24/Mauritania.png",
              "public/Flags/24/Mauritius.png",
              "public/Flags/24/Mexico.png",
              "public/Flags/24/Micronesia.png",
              "public/Flags/24/Moldova.png",
              "public/Flags/24/Monaco.png",
              "public/Flags/24/Mongolia.png",
              "public/Flags/24/Montenegro.png",
              "public/Flags/24/Montserrat.png",
              "public/Flags/24/Morocco.png",
              "public/Flags/24/Mozambique.png",
              "public/Flags/24/Myanmar(Burma).png",
              "public/Flags/24/NATO.png",
              "public/Flags/24/Namibia.png",
              "public/Flags/24/Nauru.png",
              "public/Flags/24/Nepal.png",
              "public/Flags/24/Netherlands Antilles.png",
              "public/Flags/24/Netherlands.png",
              "public/Flags/24/New Caledonia.png",
              "public/Flags/24/New Zealand.png",
              "public/Flags/24/Nicaragua.png",
              "public/Flags/24/Niger.png",
              "public/Flags/24/Nigeria.png",
              "public/Flags/24/North Korea.png",
              "public/Flags/24/Northern Cyprus.png",
              "public/Flags/24/Northern Ireland.png",
              "public/Flags/24/Norway.png",
              "public/Flags/24/OPEC.png",
              "public/Flags/24/Olimpic Movement.png",
              "public/Flags/24/Oman.png",
              "public/Flags/24/Pakistan.png",
              "public/Flags/24/Palau.png",
              "public/Flags/24/Palestine.png",
              "public/Flags/24/Panama.png",
              "public/Flags/24/Papua New Guinea.png",
              "public/Flags/24/Paraguay.png",
              "public/Flags/24/Peru.png",
              "public/Flags/24/Philippines.png",
              "public/Flags/24/Poland.png",
              "public/Flags/24/Portugal.png",
              "public/Flags/24/Puerto Rico.png",
              "public/Flags/24/Qatar.png",
              "public/Flags/24/Red Cross.png",
              "public/Flags/24/Reunion.png",
              "public/Flags/24/Romania.png",
              "public/Flags/24/Russian Federation.png",
              "public/Flags/24/Rwanda.png",
              "public/Flags/24/Saint Lucia.png",
              "public/Flags/24/Samoa.png",
              "public/Flags/24/San Marino.png",
              "public/Flags/24/Sao Tome & Principe.png",
              "public/Flags/24/Saudi Arabia.png",
              "public/Flags/24/Scotland.png",
              "public/Flags/24/Senegal.png",
              "public/Flags/24/Serbia(Yugoslavia).png",
              "public/Flags/24/Seyshelles.png",
              "public/Flags/24/Sierra Leone.png",
              "public/Flags/24/Singapore.png",
              "public/Flags/24/Slovakia.png",
              "public/Flags/24/Slovenia.png",
              "public/Flags/24/Solomon Islands.png",
              "public/Flags/24/Somalia.png",
              "public/Flags/24/Somaliland.png",
              "public/Flags/24/South Africa.png",
              "public/Flags/24/South Korea.png",
              "public/Flags/24/Spain.png",
              "public/Flags/24/Sri Lanka.png",
              "public/Flags/24/St Kitts & Nevis.png",
              "public/Flags/24/St Vincent & the Grenadines.png",
              "public/Flags/24/Sudan.png",
              "public/Flags/24/Suriname.png",
              "public/Flags/24/Swaziland.png",
              "public/Flags/24/Sweden.png",
              "public/Flags/24/Switzerland.png",
              "public/Flags/24/Syria.png",
              "public/Flags/24/Tahiti(French Polinesia).png",
              "public/Flags/24/Taiwan.png",
              "public/Flags/24/Tajikistan.png",
              "public/Flags/24/Tanzania.png",
              "public/Flags/24/Thailand.png",
              "public/Flags/24/Timor-Leste.png",
              "public/Flags/24/Togo.png",
              "public/Flags/24/Tonga.png",
              "public/Flags/24/Trinidad & Tobago.png",
              "public/Flags/24/Tunisia.png",
              "public/Flags/24/Turkey.png",
              "public/Flags/24/Turkmenistan.png",
              "public/Flags/24/Turks and Caicos Islands.png",
              "public/Flags/24/Tuvalu.png",
              "public/Flags/24/Uganda.png",
              "public/Flags/24/Ukraine.png",
              "public/Flags/24/United Arab Emirates.png",
              "public/Flags/24/United Kingdom(Great Britain).png",
              "public/Flags/24/United Nations.png",
              "public/Flags/24/United States of America(USA).png",
              "public/Flags/24/Uruguay.png",
              "public/Flags/24/Uzbekistan.png",
              "public/Flags/24/Vanuatu.png",
              "public/Flags/24/Vatican City.png",
              "public/Flags/24/Venezuela.png",
              "public/Flags/24/Viet Nam.png",
              "public/Flags/24/Virgin Islands British.png",
              "public/Flags/24/Virgin Islands US.png",
              "public/Flags/24/Wales.png",
              "public/Flags/24/Western Sahara.png",
              "public/Flags/24/Yemen.png",
              "public/Flags/24/Zambia.png",
              "public/Flags/24/Zimbabwe.png",
              "public/Flags/24/japan.png"];
          $( "#flag" ).autocomplete({
              minLength: 3,
              source: availableTags
          });
      });
      function imageIsLoaded(e) {
          $("#file").css("color","#f90");
          $('#image_preview').css("display", "block");
          $('#previewing').attr('src', e.target.result);
          $('#previewing').attr('width', '250px');
          $('#previewing').attr('height', '230px');
      }
    </script>
   $('#example').DataTable();
     </script>
</body>

</html>